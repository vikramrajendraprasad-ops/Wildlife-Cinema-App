# Wildlife Cinema – Android Studio Project

This is a real Android Studio starter project for Wildlife Cinema.

Open this folder in Android Studio, let Gradle sync, then Build APK.

Package: com.wildlifecinema.app
VersionName: 3.0
VersionCode: 1
